#pogi sige na makopya ka na wag ka na mahiya
