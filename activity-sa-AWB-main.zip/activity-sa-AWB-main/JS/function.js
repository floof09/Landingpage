for(let index = 0; index < 2000; index++) {
    const element = document.createElement('span');
    document.querySelector('.container').appendChild(element); 
}